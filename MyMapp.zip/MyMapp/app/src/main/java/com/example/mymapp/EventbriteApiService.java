package com.example.mymapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface EventbriteApiService {
    @GET("events/search/")
    Call<EventResponse> getNearbyEvents(
            @Query("location.latitude") double latitude,
            @Query("location.longitude") double longitude,
            @Query("token") String apiKey
    );
}

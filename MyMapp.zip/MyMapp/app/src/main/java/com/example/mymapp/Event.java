package com.example.mymapp;

public class Event {
    private String name;
    private String location;

    public Object getLocation() {
        return null;
    }

    public CharSequence getName() {
        return null;
    }

    // Getters and Setters
}

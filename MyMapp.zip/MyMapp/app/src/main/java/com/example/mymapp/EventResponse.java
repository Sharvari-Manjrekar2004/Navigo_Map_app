package com.example.mymapp;

import java.util.List;

public class EventResponse {
    public List<Event> events;

    public static class Event {
        public String name;
        public Start start;
        public Venue venue;

        public static class Start {
            public String local;
        }

        public static class Venue {
            public String address;
        }
    }
}

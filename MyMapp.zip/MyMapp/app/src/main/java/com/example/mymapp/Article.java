package com.example.mymapp;

import java.util.List;

public class Article {

    private String title;
    private String summary;  // Changed from 'abstract' to 'summary'
    private String url;
    private String publishedDate;  // Changed from 'published_date' to 'publishedDate'
    private List<Multimedia> multimedia;

    // Getters and Setters

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;  // Changed from getAbstract to getSummary
    }

    public void setSummary(String summary) {  // Changed from setAbstract to setSummary
        this.summary = summary;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPublishedDate() {
        return publishedDate;  // Changed from getPublishedDate to getPublishedDate
    }

    public void setPublishedDate(String publishedDate) {  // Changed from setPublishedDate to setPublishedDate
        this.publishedDate = publishedDate;
    }

    public List<Multimedia> getMultimedia() {
        return multimedia;
    }

    public void setMultimedia(List<Multimedia> multimedia) {
        this.multimedia = multimedia;
    }
}

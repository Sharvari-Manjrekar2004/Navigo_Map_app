package com.example.mymapp;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LocalEventsActivity extends AppCompatActivity {

    private ListView eventsListView;
    private EventsAdapter eventsAdapter;
    private List<Event> eventsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_events);

        eventsListView = findViewById(R.id.eventsListView);
        eventsList = new ArrayList<>();
        eventsAdapter = new EventsAdapter(this, eventsList);
        eventsListView.setAdapter(eventsAdapter);

        fetchLocalEvents();
    }

    private void fetchLocalEvents() {
        // Get the user's current location (you should already have location permissions and a location API integrated)
        double latitude = 0 /* Get current latitude */;
        double longitude = 0 /* Get current longitude */;

        // Use Eventbrite or another API to fetch local events
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://www.eventbrite.com/oauth/authorize?response_type=code&client_id=UZ4JXSQB3EWW767U5E7A&redirect_uri=YOUR_REDIRECT_URI")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        EventApiService eventApiService = retrofit.create(EventApiService.class);
        Call<EventsResponse> call = eventApiService.getEventsNearby(latitude, longitude, "UZ4JXSQB3EWW767U5E7A");
        call.enqueue(new Callback<EventsResponse>() {
            @Override
            public void onResponse(Call<EventsResponse> call, Response<EventsResponse> response) {
                if (response.isSuccessful()) {
                    EventsResponse eventsResponse = response.body();
                    if (eventsResponse != null) {
                        eventsList.addAll(eventsResponse.getEvents());
                        eventsAdapter.notifyDataSetChanged(); // Notify the adapter to refresh the ListView
                    }
                } else {
                    Toast.makeText(LocalEventsActivity.this, "Failed to retrieve events", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<EventsResponse> call, Throwable t) {
                Toast.makeText(LocalEventsActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

package com.example.mymapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class LocalLingoActivity extends AppCompatActivity {

    private EditText inputPhrase;
    private Button translateButton, voiceInputButton, voiceOutputButton, selectLanguageButton;
    private TextView translatedPhrase;

    private HashMap<String, String> translations;
    private TextToSpeech textToSpeech;
    private static final int REQUEST_CODE_SPEECH_INPUT = 100;
    private Locale selectedLocale = Locale.getDefault(); // Default locale

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_lingo);

        // Initialize UI components
        inputPhrase = findViewById(R.id.inputPhrase);
        translateButton = findViewById(R.id.translateButton);
        voiceInputButton = findViewById(R.id.voiceInputButton);
        voiceOutputButton = findViewById(R.id.voiceOutputButton);
        selectLanguageButton = findViewById(R.id.selectLanguageButton); // Button for language selection
        translatedPhrase = findViewById(R.id.translatedPhrase);

        // Initialize translations
        initializeTranslations();

        // Initialize TextToSpeech
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage(selectedLocale);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Handle missing language data
                }
            }
        });

        // Set onClickListener for the translate button
        translateButton.setOnClickListener(v -> translatePhrase());

        // Set onClickListener for voice input button
        voiceInputButton.setOnClickListener(v -> promptSpeechInput());

        // Set onClickListener for voice output button
        voiceOutputButton.setOnClickListener(v -> speakOutTranslation());

        // Set onClickListener for select language button
        selectLanguageButton.setOnClickListener(v -> selectLanguage());
    }

    // Initialize translations
    // Initialize translations
    private void initializeTranslations() {
        translations = new HashMap<>();

        // English to Hindi
        translations.put("hello", "नमस्ते");
        translations.put("goodbye", "अलविदा");
        translations.put("thank you", "धन्यवाद");
        translations.put("please", "कृपया");
        translations.put("yes", "हाँ");
        translations.put("no", "नहीं");
        translations.put("good morning", "सुप्रभात");
        translations.put("how are you", "आप कैसे हैं?");
        translations.put("what is your name", "आपका नाम क्या है?");
        translations.put("I love you", "मैं तुमसे प्यार करता हूँ");
        translations.put("where is the bathroom", "बाथरूम कहाँ है?");
        translations.put("can you help me", "क्या आप मेरी मदद कर सकते हैं?");
        translations.put("I am hungry", "मुझे भूख लगी है");
        translations.put("I am tired", "मैं थक गया हूँ");
        translations.put("what time is it", "क्या समय हुआ है?");
        translations.put("see you later", "फिर मिलेंगे");

        // Hindi to English
        translations.put("नमस्ते", "hello");
        translations.put("अलविदा", "goodbye");
        translations.put("धन्यवाद", "thank you");
        translations.put("कृपया", "please");
        translations.put("हाँ", "yes");
        translations.put("नहीं", "no");
        translations.put("सुप्रभात", "good morning");
        translations.put("आप कैसे हैं", "how are you?");
        translations.put("आपका नाम क्या है", "what is your name?");
        translations.put("मैं तुमसे प्यार करता हूँ", "I love you");
        translations.put("बाथरूम कहाँ है", "where is the bathroom?");
        translations.put("क्या आप मेरी मदद कर सकते हैं", "can you help me?");
        translations.put("मुझे भूख लगी है", "I am hungry");
        translations.put("मैं थक गया हूँ", "I am tired");
        translations.put("क्या समय हुआ है", "what time is it?");
        translations.put("फिर मिलेंगे", "see you later");

        // English to Marathi
        translations.put("hello", "नमस्कार");
        translations.put("goodbye", "आभार");
        translations.put("thank you", "धन्यवाद");
        translations.put("please", "कृपया");
        translations.put("yes", "होय");
        translations.put("no", "नाही");
        translations.put("good morning", "शुभ प्रभात");
        translations.put("how are you", "तू कसा आहेस?");
        translations.put("what is your name", "तुझे नाव काय आहे?");
        translations.put("I love you", "मी तुझ्यावर प्रेम करतो");
        translations.put("where is the bathroom", "बाथरूम कुठे आहे?");
        translations.put("can you help me", "तू माझी मदत करू शकतोस का?");
        translations.put("I am hungry", "माझं उपाशी आहे");
        translations.put("I am tired", "मी थकले आहे");
        translations.put("what time is it", "किती वाजले आहे?");
        translations.put("see you later", "नंतर भेटू");

        // Marathi to English
        translations.put("नमस्कार", "hello");
        translations.put("आभार", "goodbye");
        translations.put("धन्यवाद", "thank you");
        translations.put("कृपया", "please");
        translations.put("होय", "yes");
        translations.put("नाही", "no");
        translations.put("शुभ प्रभात", "good morning");
        translations.put("तू कसा आहेस", "how are you?");
        translations.put("तुझे नाव काय आहे", "what is your name?");
        translations.put("मी तुझ्यावर प्रेम करतो", "I love you");
        translations.put("बाथरूम कुठे आहे?", "where is the bathroom?");
        translations.put("तू माझी मदत करू शकतोस का", "can you help me?");
        translations.put("मला भूक लागली आहेे", "I am hungry");
        translations.put("मी थकले आहे", "I am tired");
        translations.put("किती वाजले आहे", "what time is it?");
        translations.put("नंतर भेटू", "see you later");

        // Hindi to Marathi
        translations.put("नमस्ते", "नमस्कार");
        translations.put("अलविदा", "आभार");
        translations.put("धन्यवाद", "धन्यवाद");
        translations.put("कृपया", "कृपया");
        translations.put("हाँ", "होय");
        translations.put("नहीं", "नाही");
        translations.put("सुप्रभात", "शुभ प्रभात");
        translations.put("आप कैसे हैं", "तू कसा आहेस?");
        translations.put("आपका नाम क्या है", "तुझे नाव काय आहे?");
        translations.put("मैं तुमसे प्यार करता हूँ", "मी तुझ्यावर प्रेम करतो");
        translations.put("बाथरूम कहाँ है", "बाथरूम कुठे आहे?");
        translations.put("क्या आप मेरी मदद कर सकते हैं?", "तू माझी मदत करू शकतोस का?");
        translations.put("मुझे भूख लगी है", "मला भूक लागली आहेे");
        translations.put("मैं थक गया हूँ", "मी थकले आहे");
        translations.put("क्या समय हुआ है", "किती वाजले आहे?");
        translations.put("फिर मिलेंगे", "नंतर भेटू");

        // Marathi to Hindi
        translations.put("नमस्कार", "नमस्ते");
        translations.put("आभार", "अलविदा");
        translations.put("धन्यवाद", "धन्यवाद");
        translations.put("कृपया", "कृपया");
        translations.put("होय", "हाँ");
        translations.put("नाही", "नहीं");
        translations.put("शुभ प्रभात", "सुप्रभात");
        translations.put("तू कसा आहेस", "आप कैसे हैं?");
        translations.put("तुझे नाव काय आहे", "आपका नाम क्या है?");
        translations.put("मी तुझ्यावर प्रेम करतो", "मैं तुमसे प्यार करता हूँ");
        translations.put("बाथरूम कुठे आहे", "बाथरूम कहाँ है?");
        translations.put("तू माझी मदत करू शकतोस का?", "क्या आप मेरी मदद कर सकते हैं?");
        translations.put("माझं उपाशी आहे", "मुझे भूख लगी है");
        translations.put("मी थकले आहे", "मैं थक गया हूँ");
        translations.put("किती वाजले आहे", "क्या समय हुआ है?");
        translations.put("नंतर भेटू", "फिर मिलेंगे");

        // Add more translations as needed
    }

    // Method to translate the input phrase
    private void translatePhrase() {
        String phrase = inputPhrase.getText().toString().trim(); // Get the input phrase and trim spaces
        String translated = translations.get(phrase); // Get the translated phrase

        // Display the translated phrase or an error message if not found
        if (translated != null) {
            translatedPhrase.setText(translated);
        } else {
            translatedPhrase.setText("Translation not available.");
        }
    }

    // Method to prompt the user for voice input
    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale.toString()); // Set the selected locale
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...");

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions, such as no recognizer available
        }
    }

    // Handle the result of the speech input
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                String spokenPhrase = result.get(0); // Get the first recognized phrase
                inputPhrase.setText(spokenPhrase); // Set it to the input field
                translatePhrase(); // Automatically translate the spoken phrase
            }
        }
    }

    // Method to read out the translated phrase
    private void speakOutTranslation() {
        String translatedText = translatedPhrase.getText().toString();
        if (!translatedText.isEmpty()) {
            textToSpeech.speak(translatedText, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    // Method to allow users to select a language for voice recognition
    private void selectLanguage() {
        // Open a dialog for the user to choose a language
        String[] languages = {"English", "Hindi", "Marathi", "Bengali", "Tamil", "Telugu", "Punjabi"};
        new AlertDialog.Builder(this)
                .setTitle("Select Language")
                .setItems(languages, (dialog, which) -> {
                    switch (which) {
                        case 0: // English
                            selectedLocale = Locale.ENGLISH;
                            break;
                        case 1: // Hindi
                            selectedLocale = new Locale("hi");
                            break;
                        case 2: // Marathi
                            selectedLocale = new Locale("mr"); // Set Marathi locale
                            break;
                        case 3: // Bengali
                            selectedLocale = new Locale("bn");
                            break;
                        case 4: // Tamil
                            selectedLocale = new Locale("ta");
                            break;
                        case 5: // Telugu
                            selectedLocale = new Locale("te");
                            break;
                        case 6: // Punjabi
                            selectedLocale = new Locale("pa");
                            break;
                    }
                    // Update TextToSpeech language
                    textToSpeech.setLanguage(selectedLocale);
                })
                .show();
    }

    @Override
    protected void onDestroy() {
        // Shutdown TextToSpeech on activity destroy
        if (textToSpeech != null) {
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}

package com.example.mymapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface NewsApiService {

    // API request to fetch news by location (country)
    @GET("top-headlines")
    Call<NewsResponse> getNewsByLocation(
            @Query("country") String country,  // The country code (e.g., "in")
            @Query("apiKey") String apiKey     // Your API key
    );

    Call<NewsResponse> getNewsByLocation(double latitude, double longitude, String apiKey);
}

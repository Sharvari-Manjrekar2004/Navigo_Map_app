package com.example.mymapp;



import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class FeedbackActivity extends AppCompatActivity {

    private EditText feedbackEditText;
    private Button submitButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        feedbackEditText = findViewById(R.id.feedbackEditText);
        submitButton = findViewById(R.id.submitButton);

        submitButton.setOnClickListener(v -> {
            String feedback = feedbackEditText.getText().toString();
            if (!feedback.isEmpty()) {
                // Handle the feedback submission (e.g., send to server or save locally)
                Toast.makeText(FeedbackActivity.this, "Feedback submitted!", Toast.LENGTH_SHORT).show();
                feedbackEditText.setText(""); // Clear the input
            } else {
                Toast.makeText(FeedbackActivity.this, "Please enter feedback.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

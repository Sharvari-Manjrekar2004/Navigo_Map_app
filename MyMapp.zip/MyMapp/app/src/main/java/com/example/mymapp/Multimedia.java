package com.example.mymapp;

public class Multimedia {

    private String url; // URL of the multimedia element
    private String caption; // Caption for the multimedia element
    private String type; // Type of multimedia (e.g., image, video)

    // Getters and Setters

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

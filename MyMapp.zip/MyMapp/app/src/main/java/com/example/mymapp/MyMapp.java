package com.example.mymapp;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.speech.RecognizerIntent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.mymapp.databinding.ActivityMyMappBinding;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.PlacesClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MyMapp extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMyMappBinding binding;
    private SearchView mapSearchView;
    private Button openUberButton;
    private Button voiceCommandButton;
    private TextView weatherTextView;
    private LatLng searchedLocation;
    private SpeechRecognizer speechRecognizer;
    private Intent speechRecognizerIntent;

    private static final String WEATHER_API_KEY = "5096da4e9614c2e4c4fe4ca7f8a8168a"; // Replace with your API key
    private static final String PLACES_API_KEY = "AIzaSyDnFqQ0lquYBKjzOBkFbeBa9OO6vuYeNn0"; // Replace with your Places API key
    private static final String DIRECTIONS_API_KEY = "AIzaSyCrmYRWL_HjBPhId4P8WIA31JOvCjxC1n8"; // Replace with your Directions API key
    private PlacesClient placesClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

      binding = ActivityMyMappBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mapSearchView = findViewById(R.id.mapSearch);
        openUberButton = findViewById(R.id.openUberButton);
        voiceCommandButton = findViewById(R.id.voiceAssistantButton);
        weatherTextView = findViewById(R.id.weatherTextView);

        FragmentManager fragmentManager = getSupportFragmentManager();
        SupportMapFragment mapFragment = (SupportMapFragment) fragmentManager.findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), PLACES_API_KEY);
        }

        placesClient = Places.createClient(this);

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) { }

            @Override
            public void onBeginningOfSpeech() { }

            @Override
            public void onRmsChanged(float rmsdB) { }

            @Override
            public void onBufferReceived(byte[] buffer) { }

            @Override
            public void onEndOfSpeech() { }

            @Override
            public void onError(int error) { }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String command = matches.get(0);
                    performVoiceCommand(command);
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) { }

            @Override
            public void onEvent(int eventType, Bundle params) { }
        });

        voiceCommandButton.setOnClickListener(v -> startVoiceRecognition());

        mapSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (!newText.isEmpty()) {
                    FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                            .setQuery(newText)
                            .build();

                    placesClient.findAutocompletePredictions(request).addOnSuccessListener(response -> {
                        for (AutocompletePrediction prediction : response.getAutocompletePredictions()) {
                            // Here you can show predictions in a list or use them for autocomplete
                            System.out.println(prediction.getPrimaryText(null).toString());
                        }
                    }).addOnFailureListener(exception -> {
                        exception.printStackTrace();
                    });
                }
                return false;
            }
        });

        openUberButton.setOnClickListener(v -> {
            if (searchedLocation != null) {
                openUberApp(searchedLocation.latitude, searchedLocation.longitude);
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu); // Inflate the menu
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_local_news) {
            Intent intent = new Intent(this, LocalNewsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_feedback) {
            Intent intent = new Intent(this, FeedbackActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_mood) {
            showMoodSelectionDialog();
            return true;
        } else if (id == R.id.action_local_lingo) {
            Intent intent = new Intent(this, LocalLingoActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_emergency) {
            // Handle Emergency Numbers dialog
            showEmergencyNumbersDialog(); // Show emergency numbers when selected
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    // Emergency Numbers Dialog function
    private void showEmergencyNumbersDialog() {
        final CharSequence[] emergencyNumbers = {"Police: 100", "Ambulance: 108", "Fire: 101"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Emergency Numbers");
        builder.setItems(emergencyNumbers, (dialog, which) -> {
            String selectedNumber = emergencyNumbers[which].toString();
            String phoneNumber = selectedNumber.split(": ")[1]; // Extract the phone number
            dialEmergencyNumber(phoneNumber); // Dial the selected number
        });
        builder.show();
    }

    private void dialEmergencyNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(intent);
    }


    private void showMoodSelectionDialog() {
        // Dialog to show mood options
        final CharSequence[] moods = {"Happy", "Adventurous", "Relaxed", "Romantic"};

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("How are you feeling?");
        builder.setItems(moods, (dialog, which) -> {
            // Mood selected
            String selectedMood = moods[which].toString();
            suggestLocationBasedOnMood(selectedMood);
        });
        builder.show();
    }

    private void suggestLocationBasedOnMood(String mood) {
        LatLng location;

        switch (mood) {
            case "Happy":
                location = new LatLng(37.7749, -122.4194); // Example location for "Happy" (San Francisco)
                break;
            case "Adventurous":
                location = new LatLng(36.1069, -112.1129); // Example location for "Adventurous" (Grand Canyon)
                break;
            case "Relaxed":
                location = new LatLng(34.0522, -118.2437); // Example location for "Relaxed" (Los Angeles)
                break;
            case "Romantic":
                location = new LatLng(48.8566, 2.3522); // Example location for "Romantic" (Paris)
                break;
            default:
                location = new LatLng(0, 0); // Default location
                break;
        }

        // Show the suggested location on the map
        mMap.addMarker(new MarkerOptions().position(location).title(mood + " Location"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(location, 10));
    }




    private void openUberApp(double latitude, double longitude) {
        String uberUri = "https://m.uber.com/ul/?action=setPickup" +
                "&pickup=my_location" +
                "&dropoff[latitude]=" + latitude +
                "&dropoff[longitude]=" + longitude;

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uberUri));
        startActivity(intent);
    }

    private void fetchWeather(double latitude, double longitude) {
        Retrofit retrofit = RetrofitClient.getClient("https://newsapi.org/v2/");
        WeatherApiService apiService = retrofit.create(WeatherApiService.class);

        Call<WeatherResponse> call = apiService.getWeather(latitude, longitude, WEATHER_API_KEY);
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherResponse weatherResponse = response.body();
                    String weatherInfo = "Temperature: " + weatherResponse.main.temp + "°C\n" +
                            "Humidity: " + weatherResponse.main.humidity + "%\n" +
                            "Weather: " + weatherResponse.weather[0].description;
                    weatherTextView.setText(weatherInfo);
                } else {
                    weatherTextView.setText("Failed to retrieve weather data.");
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                weatherTextView.setText("Error: " + t.getMessage());
            }
        });
    }

    private void performSearch(String location) {
        List<Address> addressList = null;

        if (location != null) {
            Geocoder geocoder = new Geocoder(MyMapp.this);

            try {
                addressList = geocoder.getFromLocationName(location, 10);

            } catch (IOException e) {
                e.printStackTrace();
            }

            if (addressList != null && !addressList.isEmpty()) {
                Address address = addressList.get(0);
                searchedLocation = new LatLng(address.getLatitude(), address.getLongitude());
                mMap.addMarker(new MarkerOptions().position(searchedLocation).title(location));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(searchedLocation, 10));

                openUberButton.setVisibility(View.VISIBLE);

                fetchWeather(searchedLocation.latitude, searchedLocation.longitude);

                weatherTextView.setVisibility(View.VISIBLE);

                LatLng destination = new LatLng(40.748817, -73.985428); // Example destination (Empire State Building)
                fetchDirections(searchedLocation, destination);
            }
        }
    }

    private void fetchDirections(LatLng origin, LatLng destination) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://maps.googleapis.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        DirectionsApiService apiService = retrofit.create(DirectionsApiService.class);

        String originStr = origin.latitude + "," + origin.longitude;
        String destinationStr = destination.latitude + "," + destination.longitude;

        Call<DirectionsResponse> call = apiService.getDirections(originStr, destinationStr, DIRECTIONS_API_KEY);
        call.enqueue(new Callback<DirectionsResponse>() {
            @Override
            public void onResponse(Call<DirectionsResponse> call, Response<DirectionsResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    DirectionsResponse directionsResponse = response.body();
                    if (directionsResponse.routes.length > 0) {
                        DirectionsResponse.Routes route = directionsResponse.routes[0];
                        DirectionsResponse.Routes.Leg leg = route.legs[0];
                        String directions = "Distance: " + leg.distance.text + "\n" +
                                "Duration: " + leg.duration.text + "\n";

                        for (DirectionsResponse.Routes.Leg.Step step : leg.steps) {
                            directions += step.html_instructions + "\n";
                        }
                        System.out.println(directions);
                        weatherTextView.setText(directions);

                        if (route.legs.length > 0 && route.legs[0].steps.length > 0) {
                            List<LatLng> points = decodePoly(route.legs[0].steps[0].polyline.points);
                            mMap.addPolyline(new PolylineOptions().addAll(points));
                        }
                    }
                } else {
                    System.out.println("Failed to retrieve directions.");
                }
            }

            @Override
            public void onFailure(Call<DirectionsResponse> call, Throwable t) {
                System.out.println("Error: " + t.getMessage());
            }
        });
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;
            LatLng p = new LatLng((((lat / 1E5))), (((lng / 1E5))));
            poly.add(p);
        }
        return poly;
    }

    private void startVoiceRecognition() {
        speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now");
        speechRecognizer.startListening(speechRecognizerIntent);
    }

    private void performVoiceCommand(String command) {
        if (command.toLowerCase().contains("search")) {
            String[] parts = command.split("search");
            if (parts.length > 1) {
                String query = parts[1].trim();
                performSearch(query);
            }
        } else if (command.toLowerCase().contains("directions")) {
            LatLng destination = new LatLng(40.748817, -73.985428); // Example destination (Empire State Building)
            if (searchedLocation != null) {
                fetchDirections(searchedLocation, destination);
            }
        } else if (command.toLowerCase().contains("call police")) {
            dialEmergencyNumber("100"); // Dial Police number
        } else if (command.toLowerCase().contains("call ambulance")) {
            dialEmergencyNumber("108"); // Dial Ambulance number
        } else if (command.toLowerCase().contains("call fire")) {
            dialEmergencyNumber("101"); // Dial Fire department number
        } else {
            weatherTextView.setText("Command not recognized. Try 'search [location]', 'directions', or 'call police/ambulance/fire'.");
        }
    }

}
package com.example.mymapp;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface EventApiService {
    @GET("v3/events/search/")
    Call<EventsResponse> getEventsNearby(
            @Query("latitude") double latitude,
            @Query("longitude") double longitude,
            @Query("token") String apiKey
    );
}

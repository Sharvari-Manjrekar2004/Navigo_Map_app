package com.example.mymapp;

public class WeatherResponse {
    public Main main;
    public Weather[] weather;
    public String name;

    public class Main {
        public double temp;
        public int humidity;
        public double temp_min;
        public double temp_max;
    }

    public class Weather {
        public String description;
        public String icon;
    }
}

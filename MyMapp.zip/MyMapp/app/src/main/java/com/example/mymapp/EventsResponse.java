package com.example.mymapp;

import java.util.Collection;

public class EventsResponse {
    public Collection<? extends Event> getEvents() {
        return java.util.Collections.emptyList();
    }
}

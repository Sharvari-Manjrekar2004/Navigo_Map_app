package com.example.mymapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.view.View;
import android.widget.AdapterView;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;

import java.util.ArrayList;
import java.util.List;

public class LocalNewsActivity extends AppCompatActivity {

    private ListView newsListView;
    private List<NewsResponse.Article> newsList; // Change to store Article objects
    private ArrayAdapter<String> adapter;
    private NewsApiService newsApiService;
    private static final String API_KEY = "rZcS3xlAHpqx9P85OIrT9vvh08YLFQGb"; // Replace with your actual New York Times API key

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_news); // Use your XML layout file

        newsListView = findViewById(R.id.news_list_view);
        newsList = new ArrayList<>(); // Initialize the list to hold Article objects
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        newsListView.setAdapter(adapter);

        // Initialize Retrofit with only the base URL ending with /
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.nytimes.com/svc/")  // Correct base URL
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        newsApiService = retrofit.create(NewsApiService.class);

        fetchLocalNews(); // Fetch news

        // Set up an OnItemClickListener for the ListView
        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected article
                NewsResponse.Article selectedArticle = newsList.get(position);
                String articleUrl = selectedArticle.getUrl(); // Get the article URL

                // Create an Intent to open the URL in a browser
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(articleUrl));
                startActivity(browserIntent);
            }
        });
    }

    // Fetch local news articles from the New York Times API
    private void fetchLocalNews() {
        Log.d("LocalNewsActivity", "Fetching news...");

        newsApiService.getLocalNews(API_KEY).enqueue(new Callback<NewsResponse>() {
            @Override
            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<NewsResponse.Article> articles = response.body().getArticles();
                    if (articles != null && !articles.isEmpty()) {
                        newsList.clear();
                        adapter.clear(); // Clear previous data in the adapter

                        // Loop through the articles to populate the list
                        for (NewsResponse.Article article : articles) {
                            String newsItem = article.getTitle() + "\n" + article.getAbstractText(); // Using abstract for description
                            newsList.add(article); // Add the article object to the list
                            adapter.add(newsItem); // Add the formatted string to the adapter
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Log.d("LocalNewsActivity", "No articles found.");
                        Toast.makeText(LocalNewsActivity.this, "No articles found.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.e("LocalNewsActivity", "Error: " + response.code() + " - " + response.message());
                    Toast.makeText(LocalNewsActivity.this, "Failed to fetch news.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<NewsResponse> call, Throwable t) {
                Log.e("LocalNewsActivity", "Failed to fetch news: " + t.getMessage());
                Toast.makeText(LocalNewsActivity.this, "Failed to fetch news.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Define the NewsApiService interface
    interface NewsApiService {
        @GET("topstories/v2/politics.json") // API endpoint without base URL
        Call<NewsResponse> getLocalNews(@Query("api-key") String apiKey);
    }

    // Define the NewsResponse class
    class NewsResponse {
        private List<Article> results;

        public List<Article> getArticles() {
            return results;
        }

        // Define the Article class
        class Article {
            private String title;
            private String abstractText; // Change variable name to avoid conflict with reserved keyword
            private String url;
            private String published_date;

            public String getTitle() {
                return title;
            }

            public String getAbstractText() {
                return abstractText; // This corresponds to the article's summary
            }

            public String getUrl() {
                return url;
            }

            public String getPublishedDate() {
                return published_date;
            }
        }
    }
}
